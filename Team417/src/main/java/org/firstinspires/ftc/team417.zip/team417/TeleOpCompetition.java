package org.firstinspires.ftc.team417;

/**
 * Created by user_2 on 9/20/2016.
 */
public class TeleOpCompetition extends MasterTeleOp
{
    public void runOpMode() throws InterruptedException
    {
        
    }
}
